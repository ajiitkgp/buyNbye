require("dotenv").config();

module.exports = {
  env: {
    REACT_APP_BASEURL: process.env.REACT_APP_BASEURL,
  },
};
